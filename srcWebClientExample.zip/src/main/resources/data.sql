INSERT INTO CITY (city_name,city_pincode) VALUES ('Dhaka', 1230);
INSERT INTO CITY (city_name,city_pincode) VALUES ('Delhi', 110001);
INSERT INTO CITY (city_name,city_pincode) VALUES ('Kanpur', 208001);
INSERT INTO CITY (city_name,city_pincode) VALUES ('Lucknow', 226001);
INSERT INTO CITY (city_name,city_pincode) VALUES ('Lucknow bd', 226002);