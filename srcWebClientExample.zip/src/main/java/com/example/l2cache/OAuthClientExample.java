package com.example.l2cache;

import com.example.l2cache.config.CmsProperties;
import com.example.l2cache.config.Oauth2ConfigProperties;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.MediaType;

import java.util.Objects;

@Service
@AllArgsConstructor
@Slf4j
public class OAuthClientExample {



    private final Oauth2ConfigProperties globalProperties;
    private final AuthorizedClientServiceOAuth2AuthorizedClientManager authorizedClientServiceAndManager;
    private final WebClient webClientInstance;
    private final CmsProperties cmsProperties;

    public String getJwt(){

        log.info("value of properties globalProperties.getProvider() {} ", globalProperties.getProvider());
        log.info("value of properties  globalProperties.getClientId() {} ", globalProperties.getClientId());
        log.info("value of properties globalProperties.getClientSecret() {} ", globalProperties.getClientSecret());
        log.info("value of properties globalProperties.getGrantType() {} ", globalProperties.getGrantType());
        log.info("value of properties globalProperties.getScope() {} ", globalProperties.getScope());
        log.info("value of properties globalProperties.getJwkSetUri()) {} ", globalProperties.getJwkSetUri());

        OAuth2AuthorizeRequest authorizeRequest = OAuth2AuthorizeRequest.withClientRegistrationId("keycloak")
                .principal("Demo Service")
                .build();
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientServiceAndManager.authorize(authorizeRequest);
        OAuth2AccessToken accessToken = Objects.requireNonNull(authorizedClient).getAccessToken();

        log.info("Issued: " + accessToken.getIssuedAt().toString() + ", Expires:" + accessToken.getExpiresAt().toString());
        log.info("Scopes: " + accessToken.getScopes().toString());
        log.info("Token: " + accessToken.getTokenValue());

        return accessToken.getTokenValue();

    }

    public String getValue() {

        return cmsProperties.getProcessFlow().getInitRequest();

//        return webClientInstance.get().uri(cmsProperties.getProcessFlow().getInitRequest())
//                .retrieve()
//                .bodyToFlux(String.class).blockLast();
    }

}
