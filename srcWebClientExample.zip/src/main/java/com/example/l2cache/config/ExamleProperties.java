package com.example.l2cache.config;


import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
//@PropertySource("classpath:global.properties")
@ConfigurationProperties
public class ExamleProperties {
}
