package com.example.l2cache.serializer;

import java.util.HashMap;

public final class DraftMap<K,V> extends HashMap implements DraftData {
}
