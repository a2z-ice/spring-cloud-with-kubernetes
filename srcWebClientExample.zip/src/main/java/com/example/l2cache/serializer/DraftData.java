package com.example.l2cache.serializer;

public interface DraftData {
}
