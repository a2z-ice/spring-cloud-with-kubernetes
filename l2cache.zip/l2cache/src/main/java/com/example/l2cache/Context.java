package com.example.l2cache;

public record Context(String userLoginId, String jwt, String apiVersion) {
}
