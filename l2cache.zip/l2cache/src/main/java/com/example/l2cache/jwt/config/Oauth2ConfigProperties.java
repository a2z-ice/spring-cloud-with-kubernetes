package com.example.l2cache.jwt.config;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
@Data
@Component
@ConfigurationProperties("spring.security.oauth2.client.provider.keycloak") // no prefix, find root level values.
public class Oauth2ConfigProperties {

    private String clientId;
    private String clientSecret;
    private String grantType;
    private String scope;
    private String tokenUri;
    private String jwkSetUri;
    private String provider;


}
