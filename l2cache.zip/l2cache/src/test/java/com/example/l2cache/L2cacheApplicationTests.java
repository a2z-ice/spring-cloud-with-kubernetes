package com.example.l2cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L2cacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
