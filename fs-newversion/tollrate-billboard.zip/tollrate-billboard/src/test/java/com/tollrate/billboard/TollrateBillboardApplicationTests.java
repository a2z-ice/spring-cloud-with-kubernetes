package com.tollrate.billboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TollrateBillboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
